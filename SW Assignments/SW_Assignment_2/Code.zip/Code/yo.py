import numpy as np

rng = np.random.default_rng()
for i in range(10):
    print(rng.integers(1, 10))