This Readme has instructions for testing the test cases

Use the the file "test_code.py" and ensure that the "input.txt" is located 
within the same folder as the "test_code.py" file (Code Directory).

The output file "output.txt" will be generated at the same place as the 
"test_code.py" file (Code Directory).

Note - That the test_single_case_mp function receuves the input file path and 
output file path from the "project_constants.py" file.
It has the following specifications at the time of submission : 

FP_SINGLE_CASE_IN = r"input.txt"
FP_SINGLE_CASE_OUT =  r"output.txt"

Generates a txt file - comparison_single_mp_msp.txt containing statistics about the packing made